TrueTypeFont: Hondafont
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hi everybody. This one goes out to all you "sushi racers" that probably
said "OH HELL YEA" when they saw the thumbnail. No special tricks or
numbers or uppercase letters here. The numbers and uppercase letters spell out both the wing
and the "H" logo. This font of course is free Hope you enjoy!

check out my graphic archive at www.sharkshock.uni.cc
                                  "Take a bite out of BORING design!"