      _____________________________________
	      ______________________________________
	   ___    _     _  __ __   ___  _    _  
	 // __   //    //   //   //    //___// 
	//__//  //__  //   //   //__  //   //  
	
	F  R  E  E  W  A  R  E   F  O  N  T  S
      _____________________________________
	      ______________________________________
	

      	      Although my fonts are totally free,
      	      for commercial use a donation would be
	      appropriate. I prefer money, but a product
	      sample would be fine as well. (Or both)
	      Please contact me for more info.
   
	E-Mail: nxus@wxs.nl
	 Home: http://home.wxs.nl/~hachmang/
	  Fonts: http://home.wxs.nl/~hachmang/glitch/
      
	      �1998-1999 Koen Hachmang


      _____________________________________
	      ______________________________________

	END-USER LICENCE AGREEMENT
		SOFTWARE PRODUCT FROM
			 GLITCH FREEWARE FONTS
      _____________________________________
	      ______________________________________

	SOFTWARE PRODUCT LICENSE

	The software product is protected by copyright
	laws and international copyright treaties,
	as well as other intellectual property laws
	and treaties. The software product is licensed,
	not sold.

	1. GRANT OF LICENSE.
	  This document grants you the following rights:

	- Installation and Use.
	  You may install and use an unlimited number
	  of copies of the software product.

	- Reproduction and Distribution.
	  You may reproduce and distribute an unlimited
	  number of copies of the software product;
	  provided that each copy shall be a true and
	  complete copy, including all copyright and
	  trademark notices (if applicable), and shall
	  be accompanied by a copy of this licence.
	  Copies of the software product may not be
 	  distributed for profit either on a standalone
	  basis or included as part of your own product
	  unless by prior permission of the author.

	2. DESCRIPTION OF OTHER RIGHTS AND LIMITATIONS. 

	- Restrictions on Alteration.
	  You may not rename, edit or create any
	  derivative works from the software product,
	  other than subsetting when embedding them in
	  documents unless you have permission from the
	  author.

	LIMITED WARRANTY
	
	  NO WARRANTIES.
	  Glitch Freeware Fonts expressly disclaims any
	  warranty for the software product.
	  The software product and any related documentation
	  is provided "as is" without warranty of any kind,
	  either express or implied, including, without
	  limitation, the implied warranties or
	  merchantability, fitness for a particular purpose,
	  or noninfringement. The entire risk arising out of
	  use or performance of the software product remains
	  with you.

	  NO LIABILITY FOR CONSEQUENTIAL DAMAGES.
	  In no event shall Glitch Freeware Fonts be liable 
	  for any damages whatsoever (including, without
	  limitation, damages for loss of business profits,
	  business interruption, loss of business information,
	  or any other pecuniary loss) arising out of the use
	  of or inability to use this product, even if Glitch
	  Freeware Fonts has been advised of the possibility
	  of such damages.

	3. MISCELLANEOUS

	  Should you have any questions concerning this
	  document, or if you desire to contact Glitch Freeware
	  Fonts for any reason, please contact nxus@wxs.nl,
	  or write:

		Koen Hachmang,
		Goudsbloem 91,
		5071 EW Udenhout,
		The Netherlands.