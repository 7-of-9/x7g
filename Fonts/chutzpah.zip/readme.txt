Chutzpah TTF

http://www.boo2.co.uk

This font is provided as freeware.  
You are free to use it as you wish.  All I ask is that you e-mail me ( link at the URL above ) and tell me where you used it.  

Please DO NOT rename or alter Chutzpah in any way.

Thank You
 