//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by winmain.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDB_BITMAP1                     343
#define ID_FIGHTER_VERTEXSHADER1        344
#define IDC_DEVICE_COMBO                1000
#define IDC_ADAPTER_COMBO               1002
#define IDC_FULLSCREENMODES_COMBO       1003
#define IDC_MULTISAMPLE_COMBO           1005
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_TOGGLESTART                 40004
#define IDM_SINGLESTEP                  40005
#define IDM_EXIT                        40006
#define ID_VIEW_OBJECTS_SKYDOME         40012
#define ID_VIEW_OBJECTS_TRACK           40014
#define ID_VIEW_OBJECTS_FIGHTER         40015
#define ID_VIEW_WIREFRAME               40016
#define ID_VIEW_STATS                   40020
#define ID_VIEW_FSAA                    40021
#define ID_VIEW_OBJECTS_TERRAIN2        40022
#define ID_VIEW_OBJECTS_FLATGROUND      40023
#define ID_VIEW_CAMERA_COCKPITFIXED     40026
#define ID_VIEW_CAMERA_FREE             40028
#define ID_VIEW_CAMERA_SHOWOFF          40029
#define ID_VIEW_FIGHTER_NORMAL          40030
#define ID_VIEW_FIGHTER_CHROME          40031
#define ID_VIEW_FIGHTER_GLASS           40032
#define ID_VIEW_CAMERA_BEHINDFIXED1     40033
#define ID_VIEW_CAMERA_BEHINDFIXED2     40034
#define ID_VIEW_CAMERA_BEHINDFIXED3     40035
#define ID_VIEW_CAMERA_BEHINDVARIABLE1  40036
#define ID_VIEW_CAMERA_BEHINDVARIABLE2  40037
#define ID_VIEW_CAMERA_BEHINDVARIABLE3  40038
#define ID_VIEW_CAMERA_COCKPITROLL      40039
#define ID_VIEW_HUD                     40040
#define ID_VIEW_FIGHTER_VERTEXSHADER1   40041
#define ID_ACCELERATOR40042             40042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        345
#define _APS_NEXT_COMMAND_VALUE         40045
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
