/*
 *
 * x7
 * x7_utils.h
 *
 * Utility functions.
 *
 */

#ifdef UTILS
#else

#include <windows.h>
#include <assert.h>
#include <D3DX8.h>
#include "./d3dfont.h"
#include "D3DUtil.h"
#include "DXUtil.h"

#include "x7_primitives.h"

#include "CCamera.h"

#define LOAD_RES_FROM_FILE

	extern BOOL		g_bDebugMsgs ;

	extern D3DXMATRIX g_matIdent ;

	void			SetKey( int VK, int b );

	void			SetupSpecularMaterial( D3DMATERIAL8* pMat, float r, float g, float b, float a  );
	
	int				Pow2( int i );

	void			LTrim( char* sz );
	void			RTrim( char* sz );
	void			 Trim( char* sz );
	
	DWORD			FtoDW( FLOAT f );

	void			Msg( char *sz );
	void			Msg2( char *fmt, ... );
	void			ods( char *fmt, ... );
	
	void			D3DFormat2Str( DWORD format, char *sz );
	void			D3DBlend2Str(DWORD blend, char *sz)	;

	float			rnd( void );

	BOOL			GetBBoxVisibility(LPDIRECT3DDEVICE8 pDev, const D3DXMATRIX& matProj, const D3DXMATRIX& matView, D3DVIEWPORT8* pVP, const D3DXVECTOR3& vMin, const D3DXVECTOR3& vMax);

	float			square( float f );
	void sphere_line_intersection (
    float x1, float y1 , float z1,
    float x2, float y2 , float z2,
    float x3, float y3 , float z3, float r, float* p );

BOOL SphereLineTest ( const D3DXVECTOR3& vA,	// IN:  line start
					  const D3DXVECTOR3& vB,	// IN:  line end
					  const D3DXVECTOR3& vS,	// IN:  sphere pos.
					  const float r,			// IN:  sphere radius
					  int* pN,					// OUT: no. of intersections (0, 1 or 2), set if not NULL
					  D3DXVECTOR3* pvI1,		// OUT: intersection coords 1, set if not NULL
					  D3DXVECTOR3* pvI2			// OUT: intersection coords 2. set if not NULL
				    );

	float SqrDistance (const D3DXVECTOR3& vPoint,
					   const D3DXVECTOR3& vLineA,
					   const D3DXVECTOR3& vLineB );

	HRESULT			LoadDDSTextureFromResource( LPDIRECT3DDEVICE8 pd3dDevice, 
												TCHAR* strRes, 
												LPDIRECT3DTEXTURE8* ppTex,
												TCHAR* strResType );

	HRESULT			LoadXMeshFromResource( LPDIRECT3DDEVICE8 pd3dDevice, 
										   TCHAR* strRes, 
										   LPD3DXMESH* ppMesh,
										   LPD3DXBUFFER* ppAdj,
										   LPD3DXBUFFER* ppMat,
										   DWORD* pNumMat,
										   DWORD dwOptions );
	
	void  MultVectorArb   (LPD3DXVECTOR3 v, D3DMATRIX *m) ;
	void  RotateVectorX   (LPD3DXVECTOR3 v, float n, LPD3DXVECTOR3 o) ;
	void  RotateVectorY   (LPD3DXVECTOR3 v, float n, LPD3DXVECTOR3 o) ;
	void  RotateVectorZ   (LPD3DXVECTOR3 v, float n, LPD3DXVECTOR3 o) ;
	void  RotateVectorArb (LPD3DXVECTOR3 v, float n, LPD3DXVECTOR3 o, LPD3DXVECTOR3 plane) ;
	void  TranslateVector (LPD3DXVECTOR3 v, float x, float y, float z) ;


#endif